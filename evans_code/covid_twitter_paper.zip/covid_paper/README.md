# Experiments

Experiment code for the paper ``The Case for Latent Variable vs Deep Learning Methods in Misinformation Detection: An Application to COVID-19".

The code expect the raw data and embeddings to be present under the "/data" path.

## Requirements
- Python 3.8
- scikit-learn
- pandas
- numpy
- PyTorch
- HuggingFace transformers